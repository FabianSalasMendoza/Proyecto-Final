const validarFormulario = require('./3Nombres');

// Prueba 1: Validar que la función retorna false para menos de 3 palabras
test('Menos de 3 palabras deberían retornar false', () => {
    const eventoSimulado = {
        preventDefault: jest.fn(),
    };

    const resultado = validarFormulario(eventoSimulado);

    expect(resultado).toBe(false);

    expect(eventoSimulado.preventDefault).toHaveBeenCalled();
});



// Prueba 3: Validar que la función retorna false para una cadena vacía
test('Cadena vacía debería retornar false', () => {
    const eventoSimulado = {
        preventDefault: jest.fn(),
    };
    expect(validarFormulario(eventoSimulado)).toBe(false);
    expect(eventoSimulado.preventDefault).toHaveBeenCalled();
});

// Prueba 4: Validar que la función retorna false para una cadena con espacios, pero sin palabras
test('Cadena con espacios debería retornar false', () => {
    const eventoSimulado = {
        preventDefault: jest.fn(),
    };
    expect(validarFormulario(eventoSimulado)).toBe(false);
    expect(eventoSimulado.preventDefault).toHaveBeenCalled();
});
