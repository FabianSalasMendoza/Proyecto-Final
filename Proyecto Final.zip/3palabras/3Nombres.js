var nombresAcumulados = [];

function validarFormulario(event) {
    event.preventDefault();

    var campoNombres = document.getElementById("names");

    if (!campoNombres) {
        console.error("El campo de nombres no se encuentra en el DOM.");
        return false;
    }

    var nombres = campoNombres.value.toUpperCase(); // Convertir a mayúsculas

    var palabras = nombres.split(" ");
    var palabrasNoVacias = palabras.filter(function(palabra) {
        return palabra.trim() !== "";
    });

    if (palabrasNoVacias.length < 3) {
        document.getElementById("result").innerHTML = "Por favor, ingresa al menos 3 palabras.";
        return false;
    }

    nombresAcumulados.push(nombres);
    mostrarNombresAcumulados();
    campoNombres.value = "";
    
    alert("Registro Exitoso");

    return true;
}

function mostrarNombresAcumulados() {
    document.getElementById("result").innerHTML = "Nombres ingresados:<br>" + nombresAcumulados.join("<br>");
}

// Exportar la función si estás usando Node.js
if (typeof module !== 'undefined' && module.exports) {
    module.exports = validarFormulario;
}

console.log("Fabian Salas Mendoza y Mario Cesar Gutierrez Salazar 4D");
